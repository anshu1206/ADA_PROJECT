from PIL import Image

def create_collage(image_paths, width, height):
    collage = Image.new('RGB', (width, height), color=(255, 255, 255))

    def helper(images, x, y, w, h):
        if len(images) == 1:
            img = Image.open(images[0])
            img = img.resize((w, h))
            collage.paste(img, (x, y))
            return
        
        mid = len(images) // 2

        # Decide split direction
        if w >= h:
            helper(images[:mid], x, y, w//2, h)
            helper(images[mid:], x + w//2, y, w//2, h)
        else:
            helper(images[:mid], x, y, w, h//2)
            helper(images[mid:], x, y + h//2, w, h//2)

    helper(image_paths, 0, 0, width, height)
    return collage