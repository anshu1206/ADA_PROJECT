import tkinter as tk
from tkinter import filedialog
from collage import create_collage

selected_images = []

def upload_images():
    global selected_images
    selected_images = filedialog.askopenfilenames(
        filetypes=[("Image Files", "*.jpg *.png *.jpeg")]
    )
    label.config(text=f"{len(selected_images)} images selected")
import os

def generate_collage():
    if not selected_images:
        label.config(text="Please select images first!")
        return
    
    # Create output folder if it doesn't exist
    os.makedirs("output", exist_ok=True)
    
    collage = create_collage(selected_images, 1080, 1080)
    collage.save("output/collage.jpg")
    
    label.config(text="Collage saved in output folder!")

root = tk.Tk()
root.title("Instagram Collage Generator")

tk.Button(root, text="Upload Images", command=upload_images).pack(pady=10)
tk.Button(root, text="Generate Collage", command=generate_collage).pack(pady=10)

label = tk.Label(root, text="No images selected")
label.pack()

root.mainloop()